from api_covid_ufrgs.mtr import Distancias, Rodoviarias, CovidStatus, Localizacao
